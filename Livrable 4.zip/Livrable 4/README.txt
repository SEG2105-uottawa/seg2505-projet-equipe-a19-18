This archive contains all the files of the fourth Delivrable, that is, this file(README.txt),
the UML diagram and the apk,

************************************
Ce projet �tait tester avec le emulator PIXEL 2 API 24 et debugger avec un Samsung Galaxy s9
************************************

*Groupe : A19-18

*Team Members:

- Alexander Onofrei # 300089694

- Felix Begin       # 300079520

- Simon Paquette    # 300044038

- Hadi El-Saleh     # 300028268


*Here is the link for the Github directory : https://github.com/SEG2105-uottawa/seg2505-projet-equipe-a19-18
---